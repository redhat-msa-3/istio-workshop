# Eureka Adapter for Istio on Docker

This folder provides a sample setup of Istio in Docker leveraging the Eureka registry adapter. Please follow the installation instructions from [istio.io](https://istio.io/docs/guides/bookinfo).